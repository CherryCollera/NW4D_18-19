﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            tbMain.Clear();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnOne.Text;
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnSeven.Text;
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnEight.Text;
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnNine.Text;
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnFour.Text;
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnFive.Text;
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnSix.Text;
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnTwo.Text;
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnThree.Text;
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnZero.Text;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbMain.Text);
            tbMain.Clear();


            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = true;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            if (DeclareVar.plusButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 + double.Parse(tbMain.Text);
                tbMain.Text = DeclareVar.total2.ToString();
                DeclareVar.total1 = 0;
            }

            else if (DeclareVar.minusButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 - double.Parse(tbMain.Text);
                tbMain.Text = DeclareVar.total2.ToString();
                DeclareVar.total1 = 0;
            }

            else if (DeclareVar.multiplyButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 * double.Parse(tbMain.Text);
                tbMain.Text = DeclareVar.total2.ToString();
                DeclareVar.total1 = 0;
            }

            else if (DeclareVar.divideButtonClicked == true)
            {
                DeclareVar.total2 = DeclareVar.total1 / double.Parse(tbMain.Text);
                tbMain.Text = DeclareVar.total2.ToString();
                DeclareVar.total1 = 0;
            }
        }

        private void btnDot_Click(object sender, EventArgs e)
        {
            tbMain.Text = tbMain.Text + btnDot.Text;
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbMain.Text);
            tbMain.Clear();


            DeclareVar.minusButtonClicked = true;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = false;
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbMain.Text);
            tbMain.Clear();


            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = false;
            DeclareVar.multiplyButtonClicked = true;
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = DeclareVar.total1 + double.Parse(tbMain.Text);
            tbMain.Clear();


            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.divideButtonClicked = true;
            DeclareVar.multiplyButtonClicked = false;
        }
    }
}
