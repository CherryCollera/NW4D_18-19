﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DALISAY_BALMEO_StudentExam_.Models;

namespace DALISAY_BALMEO_StudentExam_
{
    class Program
    {
        static void Main(string[] args)
        {
            Student newStudent = new Student();
            Exam myExam = new Exam();
            int ctr = 0;
            double quizScore, examScore, myExamScore, myQuiz;
            do
            {
                myExam.Score = 0;
                examScore = 0;
                try
                {
                    Console.WriteLine("Student number:");
                    newStudent.StudentNumber = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Name:");
                    newStudent.Name = Console.ReadLine();
                    Console.WriteLine("Age:");
                    newStudent.Age = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Gender");
                    newStudent.Gender = Console.ReadLine();
                }
                catch (Exception e)
                {
                    Console.WriteLine("Student number should be numeric!" + e);
                }
                for (int x = 1; x <= 4; x++)
                {
                    Console.WriteLine("Quiz" + x + " : ");
                    quizScore = Convert.ToDouble(Console.ReadLine());
                    newStudent.myGrade.Add(quizScore);
                    myQuiz = myExam.ComputeExam(0, quizScore);
                    myExam.Score += quizScore;
                }

                Console.WriteLine("Final Exam: ");
                examScore = Convert.ToDouble(Console.ReadLine());
                newStudent.myGrade.Add(examScore);

                myExamScore = myExam.ComputeExam(1, examScore);

                newStudent.ComputeGrade(myExam.Score, myExamScore);

                Console.ReadKey();
                Console.WriteLine("Press any number to continue.");
                Console.WriteLine("Press 1 to EXIT.");
                ctr = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
            } while (ctr != 1);
        }
    }
}
