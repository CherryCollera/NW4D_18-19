﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DALISAY_BALMEO_StudentExam_.Models
{
    class Student : Person
    {
        public int ID { get; set; }
        public int StudentNumber { get; set; }
        public double FinalGrade { get; set; }
        public List<double> myGrade = new List<double>();

        public void ComputeGrade(double quizScore, double examScore)
        {
            FinalGrade = quizScore + examScore;

            Console.WriteLine("Final Grade: " + FinalGrade);
            if (FinalGrade >= 60)

                Console.Write("Passed!");

            else
                Console.WriteLine("Failed!");
        }
    }
}
