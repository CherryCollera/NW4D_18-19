﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_MORADA__Pearlu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("1");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("2");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("3");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("4");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("5");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("6");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("7");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("8");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("9");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button0_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText("0");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void dot_Click(object sender, EventArgs e)
        {
            if (DeclareVar.equals_BottomClicked == true)
            {
                DeclareVar.equals_BottomClicked = false;
                textbox1.Clear();
            }
            textbox1.AppendText(".");
            if (DeclareVar.divide_BottomClicked == false && DeclareVar.plus_BottomClicked == false && DeclareVar.minus_BottomClicked == false && DeclareVar.multiply_BottomClicked == false)
            {

                DeclareVar.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVar.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void clear_Click(object sender, EventArgs e)
        {

            textbox1.Clear();
            label_history.Text = "";
            DeclareVar.divide_BottomClicked = false;
            DeclareVar.plus_BottomClicked = false;
            DeclareVar.minus_BottomClicked = false;
            DeclareVar.multiply_BottomClicked = false;
            DeclareVar.equals_BottomClicked = false;
            DeclareVar.total_1 = 0;
            DeclareVar.total_2 = 0;
        }

        private void add_Click(object sender, EventArgs e)
        {
            DeclareVar.minus_BottomClicked = false;
            DeclareVar.multiply_BottomClicked = false;
            DeclareVar.divide_BottomClicked = false;
            DeclareVar.plus_BottomClicked = true;
           
            textbox1.Clear();
        }

        private void minus_Click(object sender, EventArgs e)
        {
            DeclareVar.minus_BottomClicked = true;
            DeclareVar.multiply_BottomClicked = false;
            DeclareVar.divide_BottomClicked = false;
            DeclareVar.plus_BottomClicked = false;
           
            textbox1.Clear();
        }

        private void mul_Click(object sender, EventArgs e)
        {
            DeclareVar.minus_BottomClicked = false;
            DeclareVar.multiply_BottomClicked = true;
            DeclareVar.divide_BottomClicked = false;
            DeclareVar.plus_BottomClicked = false;
            
            textbox1.Clear();
        }

        private void divide_Click(object sender, EventArgs e)
        {
            DeclareVar.minus_BottomClicked = false;
            DeclareVar.multiply_BottomClicked = false;
            DeclareVar.divide_BottomClicked = true;
            DeclareVar.plus_BottomClicked = false;
           
            textbox1.Clear();
        }

        private void equals_Click(object sender, EventArgs e)
        {
            DeclareVar.equals_BottomClicked = true;
            if (DeclareVar.plus_BottomClicked == true)
            {
                double answer = DeclareVar.total_1 + DeclareVar.total_2;
                textbox1.Text = answer.ToString();
                DeclareVar.total_1 = 0;
                DeclareVar.total_2 = 0;
                DeclareVar.plus_BottomClicked = false;
            }
            else if (DeclareVar.minus_BottomClicked == true)
            {
                double answer = DeclareVar.total_1 - DeclareVar.total_2;
                textbox1.Text = answer.ToString();
                DeclareVar.total_1 = 0;
                DeclareVar.minus_BottomClicked = false;
            }
            else if (DeclareVar.multiply_BottomClicked == true)
            {
                double answer = DeclareVar.total_1 * DeclareVar.total_2;
                textbox1.Text = answer.ToString();
                DeclareVar.total_1 = 0;
                DeclareVar.multiply_BottomClicked = false;
            }
            else if (DeclareVar.divide_BottomClicked == true)
            {
                double answer = DeclareVar.total_1 / DeclareVar.total_2;
                textbox1.Text = answer.ToString();
                DeclareVar.total_1 = 0;
                DeclareVar.divide_BottomClicked = false;
            }
            label_history.Text = "";
        }

        private void textbox_control_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}
    