﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_MORADA__Pearlu
{
    class DeclareVar
    {
        public static double total_1 = 0;
        public static double total_2 = 0;
        public static bool minus_BottomClicked = false;
        public static bool plus_BottomClicked = false;
        public static bool divide_BottomClicked = false;
        public static bool multiply_BottomClicked = false;
        public static bool equals_BottomClicked = false;
    }
}

