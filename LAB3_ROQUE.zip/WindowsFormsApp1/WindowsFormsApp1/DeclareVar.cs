﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class DeclareVar
    {
        public static double tot1 = 0;
        public static double tot2 = 0;
        public static bool minbtnclk = false;
        public static bool plsbtnclk = false;
        public static bool divbtnclk = false;
        public static bool mulbtnclk = false;
        public static bool eqlbtnclk = false;
    }
}
