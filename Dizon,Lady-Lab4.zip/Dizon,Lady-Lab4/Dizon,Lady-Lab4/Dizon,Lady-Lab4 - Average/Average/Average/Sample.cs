﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class Sample
    {
        public string average;
        public Sample(string x)
        {
            average = x;
        }
    }
}
