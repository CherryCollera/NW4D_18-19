﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample("average");
            double first, second, third, fourth, fifth;
            Console.WriteLine("Enter 5 grades: ");
            first = Convert.ToDouble(Console.ReadLine());
            second = Convert.ToDouble(Console.ReadLine());
            third = Convert.ToDouble(Console.ReadLine());
            fourth = Convert.ToDouble(Console.ReadLine());
            fifth = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("The average is {0:0.000}.", (first + second + third + fourth + fifth) / 5);
            Console.ReadKey();
        }
    }
}
