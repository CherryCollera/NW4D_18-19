﻿using System;


namespace WindowsApplication_Lab03
{
    class DeclareVariable
    {
        public static double total_1 = 0;
        public static double total_2 = 0;

        public static bool minus_ButtonClicked = false;
        public static bool plus_ButtonClicked = false;
        public static bool divide_ButtonClicked = false;
        public static bool multiply_ButtonClicked = false;
        public static bool equals_ButtonClicked = false;
    }
}
