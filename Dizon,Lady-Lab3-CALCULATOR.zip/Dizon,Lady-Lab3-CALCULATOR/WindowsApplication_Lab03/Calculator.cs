﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsApplication_Lab03
{
    public partial class Calc : Form
    {
        public Calc()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("1");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {
               
                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("2");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("3");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("4");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("5");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("6");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("7");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }
        private void button8_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("8");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("9");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void button0_Click(object sender, EventArgs e)
        {
            textbox1.AppendText("0");
            if (DeclareVariable.divide_ButtonClicked == false && DeclareVariable.plus_ButtonClicked == false && DeclareVariable.minus_ButtonClicked == false && DeclareVariable.multiply_ButtonClicked == false)
            {

                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            else
            {
                DeclareVariable.total_2 = double.Parse(textbox1.Text);
            }
        }

        private void clear_Click(object sender, EventArgs e)
        {
            textbox1.Clear();
            label_history.Text = "";
            DeclareVariable.divide_ButtonClicked = false;
            DeclareVariable.plus_ButtonClicked = false;
            DeclareVariable.minus_ButtonClicked = false;
            DeclareVariable.multiply_ButtonClicked = false;
            DeclareVariable.equals_ButtonClicked = false;
            DeclareVariable.total_1 = 0;
            DeclareVariable.total_2 = 0;
        }

      

        private void buttondec_Click(object sender, EventArgs e)
        {
            if (textbox1.Text.Contains(".") == true)
            {
                
            }
            else
            {
                textbox1.AppendText(".");
            }
        }


        private void add_Click(object sender, EventArgs e)
        {
            DeclareVariable.minus_ButtonClicked = false;
            DeclareVariable.multiply_ButtonClicked = false;
            DeclareVariable.divide_ButtonClicked = false;
            DeclareVariable.plus_ButtonClicked = true;
            if (textbox1.Text == "")
            {
                DeclareVariable.total_1 = double.Parse(label_history.Text);
            }
            else
            {
                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            textbox1.Clear();

            label_history.Text = Convert.ToString(DeclareVariable.total_1);
        }



        private void subtract_Click(object sender, EventArgs e)
        {
            DeclareVariable.plus_ButtonClicked = false;
            DeclareVariable.multiply_ButtonClicked = false;
            DeclareVariable.divide_ButtonClicked = false;
            DeclareVariable.minus_ButtonClicked = true;
            if (textbox1.Text == "")
            {
                DeclareVariable.total_1 = double.Parse(label_history.Text);
            }
            else
            {
                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            textbox1.Clear();

            label_history.Text = Convert.ToString(DeclareVariable.total_1);
        }

        private void multiply_Click(object sender, EventArgs e)
        {
            DeclareVariable.plus_ButtonClicked = false;
            DeclareVariable.minus_ButtonClicked = false;
            DeclareVariable.divide_ButtonClicked = false;
            DeclareVariable.multiply_ButtonClicked = true;
            if (textbox1.Text == "")
            {
                DeclareVariable.total_1 = double.Parse(label_history.Text);
            }
            else
            {
                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            textbox1.Clear();
            label_history.Text = Convert.ToString(DeclareVariable.total_1);
        }

        private void divide_Click(object sender, EventArgs e)
        {
            DeclareVariable.plus_ButtonClicked = false;
            DeclareVariable.minus_ButtonClicked = false;
            DeclareVariable.multiply_ButtonClicked = false;
            DeclareVariable.divide_ButtonClicked = true;
            if (textbox1.Text == "")
            {
                DeclareVariable.total_1 = double.Parse(label_history.Text);
            }
            else
            {
                DeclareVariable.total_1 = double.Parse(textbox1.Text);
            }
            textbox1.Clear();

            label_history.Text = Convert.ToString(DeclareVariable.total_1);
        }


        private void equals_Click(object sender, EventArgs e)
        {
            DeclareVariable.equals_ButtonClicked = true;
                if (DeclareVariable.plus_ButtonClicked == true)
                {
                    double answer = DeclareVariable.total_1 + DeclareVariable.total_2;
                    textbox1.Text = answer.ToString();
                    DeclareVariable.total_1 = 0;
                    DeclareVariable.plus_ButtonClicked = false;
                }
                else if (DeclareVariable.minus_ButtonClicked == true)
                {
                    double answer = DeclareVariable.total_1 - DeclareVariable.total_2;
                    textbox1.Text = answer.ToString();
                    DeclareVariable.total_1 = 0;
                    DeclareVariable.minus_ButtonClicked = false;
                }
                else if (DeclareVariable.multiply_ButtonClicked == true)
                {
                    double answer = DeclareVariable.total_1 * DeclareVariable.total_2;
                    textbox1.Text = answer.ToString();
                    DeclareVariable.total_1 = 0;
                    DeclareVariable.multiply_ButtonClicked = false;
                }
                else if (DeclareVariable.divide_ButtonClicked == true)
                {
                    double answer = DeclareVariable.total_1 / DeclareVariable.total_2;
                    textbox1.Text = answer.ToString();
                    DeclareVariable.total_1 = 0;
                    DeclareVariable.divide_ButtonClicked = false;
                }
        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void textbox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}