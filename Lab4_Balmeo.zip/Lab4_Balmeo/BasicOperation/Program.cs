﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            Sum s = new Sum();
            Console.WriteLine("The sum is " + DeclareVariable.sum);
            Console.ReadLine();
        }
    }
}
