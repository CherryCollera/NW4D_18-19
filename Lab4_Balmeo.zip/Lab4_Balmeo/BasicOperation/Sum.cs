﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class Sum
    {
        public Sum()
        {
            DeclareVariable var = new DeclareVariable();
            Console.WriteLine(var);
            DeclareVariable.sum = DeclareVariable.num1 + DeclareVariable.num2;
            Console.ReadLine();
        }
    }
}
