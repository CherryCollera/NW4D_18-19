﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation
{
    class DeclareVariable
    {
        public static int num1, num2, sum;
        public DeclareVariable()
        {
            Console.Write("Enter first number:\t");
            num1 = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter second number:\t");
            num2 = Convert.ToInt16(Console.ReadLine());

        }
    }
}
